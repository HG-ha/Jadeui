---
trigger: always_on
---

Follow the results defined in the top level file ".cursorrules" to the best of your abilities.
